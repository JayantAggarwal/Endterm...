const express = require('express');
const app = express();
const cors = require('cors');
const connectDB = require('./db');
const port = process.env.PORT || 5000;
const corsOptions = {
    origin: 'http://localhost:3000',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
  };
  
app.use(cors(corsOptions));
app.use(express.json());
app.use('/api/auth',require('./routes/auth'))
connectDB();
// const storage = multer.diskStorage({
//     destination: function(req, file, cb) {
//       cb(null, path.join(__dirname, 'uploads'));
//     },
//     filename: function(req, file, cb) {
//       const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
//       cb(null, file.fieldname + '-' + uniqueSuffix + file.originalname); // Specify the filename
//     }
//   });
  
//   const upload = multer({ storage: storage });
  

// app.post('/api/auth/users/upload', upload.single('image'), async (req, res) => {
//     try {
//       // Find the user document based on the user's email
//       const user = await User.findOne({ email: req.body.email });
  
//       if (!user) {
//         return res.status(404).send("User not found.");
//       }
  
//       // Update the user document with the image data
//       user.image.data = req.file.buffer;
//       user.image.contentType = req.file.mimetype;
  
//       // Save the user document
//       await user.save();
  
//       res.send("File uploaded and user document updated.");
//     } catch (error) {
//       console.error(error);
//       res.status(500).send("Error occurred while uploading the file: " + error.message);
//     }
//   });
  
app.use('/api/auth', require('./routes/auth'));

app.listen(port, () => {
  console.log(`Server started on: http://localhost:${port}`);
});