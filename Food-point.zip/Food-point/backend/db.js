const mongoose = require('mongoose');

const uri = process.env.url
const connectDB = ()=> mongoose.connect(uri).then(()=>{
    console.log("connected to mongo db");
}).catch(err=>{
    console.log(`Error : ${err}` );
})

module.exports = connectDB;


