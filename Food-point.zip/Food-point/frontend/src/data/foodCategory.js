const foodCategory = [
    {
      id: 1,
      CategoryName: "Starter"
    },
    {
      id: 2,
      CategoryName: "Biryani/Rice"
    },
    {
      id: 3,
      CategoryName: "Pizza"
    }
  ];
  
  module.exports = foodCategory;
  